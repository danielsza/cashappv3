; Cash Drawer Client Installer
; Version 3.0
; Inno Setup Script

#define MyAppName "Cash Drawer Client"
#define MyAppVersion "3.0.0"
#define MyAppPublisher "Your Company"
#define MyAppURL "https://yourcompany.com"
#define MyAppExeName "CashClient.py"

[Setup]
; Application information
AppId={{B2C3D4E5-F6G7-8901-BCDE-FG2345678901}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}

; Installation directories
DefaultDirName={autopf}\CashApp\Client
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes

; Output
OutputDir=..\Installers
OutputBaseFilename=CashDrawer_Client_v3.0_Setup
SetupIconFile=..\Icons\client.ico

; Compression
Compression=lzma2/max
SolidCompression=yes

; Visual style
WizardStyle=modern
WizardImageFile=..\Icons\installer_banner.bmp
WizardSmallImageFile=..\Icons\installer_small.bmp

; Privileges
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=commandline dialog

; Other
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce
Name: "quicklaunchicon"; Description: "{cm:CreateQuickLaunchIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "autoconnect"; Description: "Auto-connect to server on startup"; GroupDescription: "Connection Options:"; Flags: checkedonce
Name: "discoveryserver"; Description: "Auto-discover servers on first run"; GroupDescription: "Connection Options:"; Flags: checkedonce

[Files]
; Main application file
Source: "..\Client\CashClient.py"; DestDir: "{app}"; Flags: ignoreversion

; Batch file
Source: "..\Client\StartClient.bat"; DestDir: "{app}"; Flags: ignoreversion

; Dependencies
Source: "..\requirements.txt"; DestDir: "{app}"; Flags: ignoreversion

; Documentation
Source: "..\README.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\QUICK_START.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\FAQ.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\PENNY_ROUNDING.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\MACOS_COMPATIBILITY.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\START_HERE.md"; DestDir: "{app}\Docs"; Flags: ignoreversion

[Dirs]
Name: "{app}\Config"; Permissions: users-modify

[Icons]
; Start Menu
Name: "{group}\Cash Drawer"; Filename: "pythonw.exe"; Parameters: """{app}\CashClient.py"""; WorkingDir: "{app}"; IconFilename: "{app}\client.ico"
Name: "{group}\Documentation"; Filename: "{app}\Docs\START_HERE.md"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"

; Desktop icon
Name: "{autodesktop}\Cash Drawer"; Filename: "pythonw.exe"; Parameters: """{app}\CashClient.py"""; WorkingDir: "{app}"; Tasks: desktopicon; IconFilename: "{app}\client.ico"

; Quick Launch
Name: "{userappdata}\Microsoft\Internet Explorer\Quick Launch\Cash Drawer"; Filename: "pythonw.exe"; Parameters: """{app}\CashClient.py"""; WorkingDir: "{app}"; Tasks: quicklaunchicon

[Registry]
; Store installation path
Root: HKCU; Subkey: "Software\CashApp\Client"; ValueType: string; ValueName: "InstallPath"; ValueData: "{app}"

[Code]
var
  PythonPath: String;
  PythonVersion: String;
  ResultCode: Integer;
  InstallPython: Boolean;
  ConfigPage: TInputOptionWizardPage;
  ServerPage: TInputQueryWizardPage;

// Check if Python is installed
function IsPythonInstalled(): Boolean;
begin
  Result := False;
  
  // Check for Python 3.8+
  if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.11\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.11';
    Result := True;
  end
  else if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.10\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.10';
    Result := True;
  end
  else if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.9\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.9';
    Result := True;
  end
  else if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.8\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.8';
    Result := True;
  end;
  
  // Also check HKCU
  if not Result then
  begin
    if RegQueryStringValue(HKEY_CURRENT_USER, 'SOFTWARE\Python\PythonCore\3.11\InstallPath', '', PythonPath) then
    begin
      PythonVersion := '3.11';
      Result := True;
    end;
  end;
end;

// Initialize setup
function InitializeSetup(): Boolean;
begin
  Result := True;
  InstallPython := False;
  
  if not IsPythonInstalled() then
  begin
    if MsgBox('Python 3.8 or higher is required but not found.' + #13#10 + #13#10 + 
              'Would you like to download and install Python now?' + #13#10 + #13#10 +
              'The installer will open your browser to python.org.', 
              mbConfirmation, MB_YESNO) = IDYES then
    begin
      ShellExec('open', 'https://www.python.org/downloads/', '', '', SW_SHOW, ewNoWait, ResultCode);
      MsgBox('Please install Python and run this installer again.', mbInformation, MB_OK);
      Result := False;
    end
    else
    begin
      MsgBox('Python is required to run Cash Drawer Client.' + #13#10 + 
             'Installation will continue, but the application will not work until Python is installed.', 
             mbInformation, MB_OK);
      InstallPython := True;
    end;
  end;
end;

// Initialize wizard pages
procedure InitializeWizard();
begin
  // Server configuration page (optional - can use auto-discovery)
  ServerPage := CreateInputQueryPage(wpSelectTasks,
    'Server Configuration (Optional)', 
    'Configure server addresses',
    'Enter server addresses or leave blank to use auto-discovery.' + #13#10 + 
    'Auto-discovery will find servers automatically on your network.');
  
  ServerPage.Add('Primary Server IP Address:', False);
  ServerPage.Add('Secondary Server IP Address (optional):', False);
  
  // Set empty defaults (will use auto-discovery)
  ServerPage.Values[0] := '';
  ServerPage.Values[1] := '';
end;

// Install Python packages
procedure InstallPythonPackages();
var
  ResultCode: Integer;
begin
  if FileExists(PythonPath + 'python.exe') then
  begin
    // Note: Client doesn't need pyserial, but we'll install requirements anyway
    Exec(PythonPath + 'python.exe', '-m pip install --upgrade pip', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  end;
end;

// Create default configuration
procedure CreateDefaultConfig();
var
  ConfigFile: String;
  ConfigLines: TArrayOfString;
  PrimaryServer: String;
  SecondaryServer: String;
  AutoConnect: String;
begin
  ConfigFile := ExpandConstant('{app}\client_config.ini');
  
  // Get server values from wizard
  PrimaryServer := ServerPage.Values[0];
  SecondaryServer := ServerPage.Values[1];
  
  // Get auto-connect preference
  if WizardIsTaskSelected('autoconnect') then
    AutoConnect := 'true'
  else
    AutoConnect := 'false';
  
  SetArrayLength(ConfigLines, 7);
  ConfigLines[0] := '[Client]';
  ConfigLines[1] := 'PrimaryServer = ' + PrimaryServer;
  ConfigLines[2] := 'PrimaryPort = 5000';
  ConfigLines[3] := 'SecondaryServer = ' + SecondaryServer;
  ConfigLines[4] := 'SecondaryPort = 5000';
  ConfigLines[5] := 'AutoConnect = ' + AutoConnect;
  ConfigLines[6] := 'RememberUsername = true';
  
  SaveStringsToFile(ConfigFile, ConfigLines, False);
end;

// Run after installation
procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
begin
  if CurStep = ssPostInstall then
  begin
    // Install Python packages
    if IsPythonInstalled() then
    begin
      InstallPythonPackages();
    end;
    
    // Create default configuration
    CreateDefaultConfig();
  end;
end;

// Should skip server page if auto-discovery is selected
function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := False;
  
  // Skip server config page if auto-discovery is selected
  if (PageID = ServerPage.ID) and WizardIsTaskSelected('discoveryserver') then
    Result := True;
end;

[Run]
; Run client after install
Filename: "pythonw.exe"; Parameters: """{app}\CashClient.py"""; Description: "Launch Cash Drawer Client"; Flags: postinstall nowait skipifsilent

; Open documentation
Filename: "{app}\Docs\START_HERE.md"; Description: "View documentation"; Flags: postinstall shellexec skipifsilent unchecked

[UninstallDelete]
Type: filesandordirs; Name: "{app}\Config"
Type: files; Name: "{app}\*.pyc"
Type: files; Name: "{app}\client_config.ini"

[Messages]
WelcomeLabel2=This will install [name/ver] on your computer.%n%nThis is the client application for opening cash drawers and entering transactions.%n%nYou will need:%n• Python 3.8 or higher%n• Network connection to servers%n%n
FinishedLabel=Installation complete!%n%nNext steps:%n1. Launch the Cash Drawer Client%n2. Let it auto-discover servers (or enter manually)%n3. Login with your credentials%n4. Start using the system!
