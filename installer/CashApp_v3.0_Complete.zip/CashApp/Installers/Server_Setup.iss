; Cash Drawer Server Installer
; Version 3.0
; Inno Setup Script

#define MyAppName "Cash Drawer Server"
#define MyAppVersion "3.0.0"
#define MyAppPublisher "Your Company"
#define MyAppURL "https://yourcompany.com"
#define MyAppExeName "CashServer.py"

[Setup]
; Application information
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}

; Installation directories
DefaultDirName={autopf}\CashApp\Server
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes

; Output
OutputDir=..\Installers
OutputBaseFilename=CashDrawer_Server_v3.0_Setup
SetupIconFile=..\Icons\server.ico

; Compression
Compression=lzma2/max
SolidCompression=yes

; Visual style
WizardStyle=modern
WizardImageFile=..\Icons\installer_banner.bmp
WizardSmallImageFile=..\Icons\installer_small.bmp

; Privileges
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog

; Other
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "quicklaunchicon"; Description: "{cm:CreateQuickLaunchIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "startupicon"; Description: "Run server automatically at startup"; GroupDescription: "Startup Options:"; Flags: unchecked
Name: "firewall"; Description: "Configure Windows Firewall (Recommended)"; GroupDescription: "Network Configuration:"; Flags: checkedonce
Name: "createusers"; Description: "Create initial user accounts after installation"; GroupDescription: "Post-Installation:"; Flags: checkedonce

[Files]
; Main application files
Source: "..\Server\CashServer.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Server\ServerConfig.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Server\UserManager.py"; DestDir: "{app}"; Flags: ignoreversion

; Batch files
Source: "..\Server\StartServer.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Server\ConfigureServer.bat"; DestDir: "{app}"; Flags: ignoreversion

; Dependencies
Source: "..\requirements.txt"; DestDir: "{app}"; Flags: ignoreversion

; Documentation
Source: "..\README.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\QUICK_START.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\INSTALLATION_GUIDE.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\FAQ.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\SERVER_DISCOVERY.md"; DestDir: "{app}\Docs"; Flags: ignoreversion
Source: "..\START_HERE.md"; DestDir: "{app}\Docs"; Flags: ignoreversion

; Create directories
[Dirs]
Name: "{app}\Logs"; Permissions: users-modify
Name: "{app}\Config"; Permissions: users-modify

[Icons]
; Start Menu
Name: "{group}\Cash Server"; Filename: "pythonw.exe"; Parameters: """{app}\CashServer.py"""; WorkingDir: "{app}"; IconFilename: "{app}\server.ico"
Name: "{group}\Configure Server"; Filename: "pythonw.exe"; Parameters: """{app}\ServerConfig.py"""; WorkingDir: "{app}"; IconFilename: "{app}\config.ico"
Name: "{group}\User Manager"; Filename: "cmd.exe"; Parameters: "/k python ""{app}\UserManager.py"""; WorkingDir: "{app}"; IconFilename: "{app}\users.ico"
Name: "{group}\Documentation"; Filename: "{app}\Docs\START_HERE.md"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"

; Desktop icons
Name: "{autodesktop}\Cash Server"; Filename: "pythonw.exe"; Parameters: """{app}\CashServer.py"""; WorkingDir: "{app}"; Tasks: desktopicon
Name: "{autodesktop}\Configure Server"; Filename: "pythonw.exe"; Parameters: """{app}\ServerConfig.py"""; WorkingDir: "{app}"; Tasks: desktopicon

; Quick Launch
Name: "{userappdata}\Microsoft\Internet Explorer\Quick Launch\Cash Server"; Filename: "pythonw.exe"; Parameters: """{app}\CashServer.py"""; WorkingDir: "{app}"; Tasks: quicklaunchicon

; Startup
Name: "{commonstartup}\Cash Server"; Filename: "pythonw.exe"; Parameters: """{app}\CashServer.py"""; WorkingDir: "{app}"; Tasks: startupicon

[Registry]
; Add to PATH (optional)
Root: HKLM; Subkey: "SYSTEM\CurrentControlSet\Control\Session Manager\Environment"; ValueType: expandsz; ValueName: "Path"; ValueData: "{olddata};{app}"; Check: NeedsAddPath('{app}')

[Code]
var
  PythonPath: String;
  PythonVersion: String;
  ResultCode: Integer;
  InstallPython: Boolean;
  ConfigPage: TInputOptionWizardPage;
  ServerIDEdit: TEdit;
  COMPortCombo: TNewComboBox;
  PeerServerEdit: TEdit;

// Check if Python is installed
function IsPythonInstalled(): Boolean;
var
  PythonKey: String;
begin
  Result := False;
  
  // Check for Python 3.8+
  if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.11\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.11';
    Result := True;
  end
  else if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.10\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.10';
    Result := True;
  end
  else if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.9\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.9';
    Result := True;
  end
  else if RegQueryStringValue(HKEY_LOCAL_MACHINE, 'SOFTWARE\Python\PythonCore\3.8\InstallPath', '', PythonPath) then
  begin
    PythonVersion := '3.8';
    Result := True;
  end;
end;

// Initialize wizard
function InitializeSetup(): Boolean;
begin
  Result := True;
  InstallPython := False;
  
  if not IsPythonInstalled() then
  begin
    if MsgBox('Python 3.8 or higher is required but not found.' + #13#10 + #13#10 + 
              'Would you like to download and install Python now?' + #13#10 + #13#10 +
              'The installer will open your browser to python.org.', 
              mbConfirmation, MB_YESNO) = IDYES then
    begin
      ShellExec('open', 'https://www.python.org/downloads/', '', '', SW_SHOW, ewNoWait, ResultCode);
      MsgBox('Please install Python and run this installer again.', mbInformation, MB_OK);
      Result := False;
    end
    else
    begin
      MsgBox('Python is required to run Cash Server.' + #13#10 + 
             'Installation will continue, but the application will not work until Python is installed.', 
             mbInformation, MB_OK);
      InstallPython := True;
    end;
  end;
end;

// Create custom configuration page
procedure InitializeWizard();
begin
  // Create configuration page
  ConfigPage := CreateInputOptionPage(wpSelectTasks,
    'Server Configuration', 'Configure basic server settings',
    'Enter the basic configuration for this server. You can change these later using the Configuration tool.',
    False, False);
  
  // Server ID
  ConfigPage.Add('Server ID (SERVER1 or SERVER2):');
  
  // COM Port
  ConfigPage.Add('COM Port (e.g., COM10):');
  
  // Peer Server (optional)
  ConfigPage.Add('Peer Server IP (optional, for failover):');
  
  // Set defaults
  ConfigPage.Values[0] := True;
  ConfigPage.Values[1] := True;
  ConfigPage.Values[2] := False;
end;

// Check if path needs to be added
function NeedsAddPath(Param: string): Boolean;
var
  OrigPath: string;
begin
  if not RegQueryStringValue(HKEY_LOCAL_MACHINE,
    'SYSTEM\CurrentControlSet\Control\Session Manager\Environment',
    'Path', OrigPath)
  then begin
    Result := True;
    exit;
  end;
  Result := Pos(';' + Param + ';', ';' + OrigPath + ';') = 0;
end;

// Get available COM ports
function GetCOMPorts(): String;
var
  Ports: TArrayOfString;
  I: Integer;
  Result: String;
begin
  Result := '';
  // This is simplified - in real implementation would enumerate COM ports
  Result := 'COM1;COM2;COM3;COM4;COM5;COM6;COM7;COM8;COM9;COM10';
end;

// Install Python packages
procedure InstallPythonPackages();
var
  ResultCode: Integer;
begin
  if FileExists(PythonPath + 'python.exe') then
  begin
    Exec(PythonPath + 'python.exe', '-m pip install --upgrade pip', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
    Exec(PythonPath + 'python.exe', '-m pip install -r "' + ExpandConstant('{app}') + '\requirements.txt"', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  end;
end;

// Configure Windows Firewall
procedure ConfigureFirewall();
var
  ResultCode: Integer;
begin
  // Allow TCP port 5000
  Exec('netsh', 'advfirewall firewall add rule name="Cash Server TCP" dir=in action=allow protocol=TCP localport=5000', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  
  // Allow UDP port 5001 (discovery)
  Exec('netsh', 'advfirewall firewall add rule name="Cash Server Discovery" dir=in action=allow protocol=UDP localport=5001', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
end;

// Create default configuration
procedure CreateDefaultConfig();
var
  ConfigFile: String;
  ConfigLines: TArrayOfString;
begin
  ConfigFile := ExpandConstant('{app}\server_config.ini');
  
  SetArrayLength(ConfigLines, 20);
  ConfigLines[0] := '[Server]';
  ConfigLines[1] := 'ServerID = SERVER1';
  ConfigLines[2] := 'Port = 5000';
  ConfigLines[3] := 'PeerServerHost = ';
  ConfigLines[4] := 'PeerServerPort = 5000';
  ConfigLines[5] := 'COMPort = COM10';
  ConfigLines[6] := 'RelayPin = DTR';
  ConfigLines[7] := 'RelayDuration = 0.5';
  ConfigLines[8] := 'LogPath = \\partsrv2\Parts\Cash';
  ConfigLines[9] := 'LocalLogPath = ' + ExpandConstant('{app}\Logs');
  ConfigLines[10] := 'EnableEmailAlerts = false';
  ConfigLines[11] := 'SMTPServer = ';
  ConfigLines[12] := 'AlertEmail = ';
  ConfigLines[13] := '';
  ConfigLines[14] := '[Security]';
  ConfigLines[15] := 'MaxFailedAttempts = 3';
  ConfigLines[16] := 'LockoutDuration = 300';
  ConfigLines[17] := 'SessionTimeout = 3600';
  
  SaveStringsToFile(ConfigFile, ConfigLines, False);
end;

// Run after installation
procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
begin
  if CurStep = ssPostInstall then
  begin
    // Install Python packages
    if IsPythonInstalled() then
    begin
      InstallPythonPackages();
    end;
    
    // Configure firewall if selected
    if WizardIsTaskSelected('firewall') then
    begin
      ConfigureFirewall();
    end;
    
    // Create default configuration
    CreateDefaultConfig();
    
    // Launch configuration tool if selected
    if WizardIsTaskSelected('createusers') then
    begin
      Exec('pythonw.exe', '"' + ExpandConstant('{app}') + '\ServerConfig.py"', '', SW_SHOW, ewNoWait, ResultCode);
    end;
  end;
end;

[Run]
; Run configuration tool after install (optional)
Filename: "pythonw.exe"; Parameters: """{app}\ServerConfig.py"""; Description: "Configure server now"; Flags: postinstall nowait skipifsilent unchecked

; Run user manager (optional)
Filename: "cmd.exe"; Parameters: "/k python ""{app}\UserManager.py"""; Description: "Create user accounts now"; Flags: postinstall nowait skipifsilent unchecked

; Open documentation
Filename: "{app}\Docs\START_HERE.md"; Description: "View documentation"; Flags: postinstall shellexec skipifsilent unchecked

[UninstallDelete]
Type: filesandordirs; Name: "{app}\Logs"
Type: filesandordirs; Name: "{app}\Config"
Type: files; Name: "{app}\*.pyc"
Type: files; Name: "{app}\server_config.ini"
Type: files; Name: "{app}\users.json"

[UninstallRun]
; Remove firewall rules
Filename: "netsh"; Parameters: "advfirewall firewall delete rule name=""Cash Server TCP"""; Flags: runhidden
Filename: "netsh"; Parameters: "advfirewall firewall delete rule name=""Cash Server Discovery"""; Flags: runhidden

[Messages]
WelcomeLabel2=This will install [name/ver] on your computer.%n%nThis server controls the cash drawer hardware and handles client authentication.%n%nYou will need:%n• Python 3.8 or higher%n• USB-to-Serial adapter%n• Administrator privileges
FinishedLabel=Installation complete!%n%nNext steps:%n1. Configure COM port in Device Manager%n2. Run Server Configuration tool%n3. Create user accounts with User Manager%n4. Start the server
